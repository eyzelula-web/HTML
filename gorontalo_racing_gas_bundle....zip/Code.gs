/**
 * ============================================================================
 * REALISTIC RACING SIMULATOR — GORONTALO EDITION
 * Bagian 1: Code.gs (Backend Google Apps Script)
 * ============================================================================
 * Fitur Backend:
 * 1. doGet(e)              : Merender Web App (Index.html) dengan XFrameOptionsMode.ALLOWALL
 * 2. initDatabase()        : Inisialisasi otomatis Sheet "Leaderboard" & "GarageLogs"
 * 3. saveRaceResult(data)  : Menyimpan hasil balapan 1 menit (Urutan Finish, Pengemudi,
 *                            Mobil/Motor Balap, Warna, Sirkuit/Medan, Cuaca, Waktu)
 * 4. getLeaderboard(limit) : Mengambil daftar Urutan Finish & Rekor Terbaik dari Spreadsheet
 */

const DB_SHEETS = {
  LEADERBOARD: 'Leaderboard',
  GARAGE_LOGS: 'GarageLogs'
};

/**
 * Menampilkan halaman utama aplikasi web saat URL Web App diakses.
 */
function doGet(e) {
  initDatabase();
  return HtmlService.createTemplateFromFile('Index')
    .evaluate()
    .setTitle('REALISTIC RACING SIMULATOR — GORONTALO 3D')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/**
 * Inisialisasi Database Google Sheets (jalankan sekali dari Editor atau otomatis saat doGet).
 */
function initDatabase() {
  const ss = getOrCreateSpreadsheet_();

  // 1. Sheet Leaderboard
  let lbSheet = ss.getSheetByName(DB_SHEETS.LEADERBOARD);
  if (!lbSheet) {
    lbSheet = ss.insertSheet(DB_SHEETS.LEADERBOARD);
    lbSheet.appendRow([
      'Timestamp',
      'Nama Pengemudi',
      'Tipe Kendaraan',
      'Nama Mobil / Motor',
      'Warna Kendaraan',
      'Lokasi Sirkuit',
      'Kondisi Jalan (Medan)',
      'Cuaca',
      'Urutan Finish',
      'Waktu Tempuh (Detik)',
      'Jarak Tempuh (Meter)',
      'Skor Drift'
    ]);
    lbSheet.getRange(1, 1, 1, 12).setFontWeight('bold').setBackground('#e11d48').setFontColor('#ffffff');
    lbSheet.setFrozenRows(1);
  }

  // 2. Sheet GarageLogs
  let garageSheet = ss.getSheetByName(DB_SHEETS.GARAGE_LOGS);
  if (!garageSheet) {
    garageSheet = ss.insertSheet(DB_SHEETS.GARAGE_LOGS);
    garageSheet.appendRow([
      'Timestamp',
      'Nama Pengemudi',
      'Karakter Pembalap',
      'Kendaraan Dipilih',
      'Warna Cat',
      'Lokasi Sirkuit',
      'Medan Jalan',
      'Cuaca'
    ]);
    garageSheet.getRange(1, 1, 1, 8).setFontWeight('bold').setBackground('#18181b').setFontColor('#ffffff');
    garageSheet.setFrozenRows(1);
  }

  return {
    status: 'success',
    spreadsheetId: ss.getId(),
    spreadsheetUrl: ss.getUrl(),
    message: 'Database Spreadsheet berhasil diinisialisasi!'
  };
}

/**
 * Menyimpan hasil balapan (1 Menit / Circuit Race / Time Trial) ke Sheet Leaderboard.
 * Dipanggil dari client menggunakan google.script.run.saveRaceResult(payload)
 */
function saveRaceResult(payload) {
  try {
    const ss = getOrCreateSpreadsheet_();
    let sheet = ss.getSheetByName(DB_SHEETS.LEADERBOARD);
    if (!sheet) {
      initDatabase();
      sheet = ss.getSheetByName(DB_SHEETS.LEADERBOARD);
    }

    const now = new Date();
    const rowData = [
      Utilities.formatDate(now, Session.getScriptTimeZone() || 'Asia/Makassar', 'yyyy-MM-dd HH:mm:ss'),
      payload.driverName || 'ANDI PRATAMA',
      payload.vehicleCategory || 'SUPERCAR / MOTOR',
      payload.vehicleName || 'FERRARI SF90 STRADALE',
      payload.paintColor || '#dc2626',
      payload.trackLocation || 'Pegunungan Tilongkabila (Gorontalo)',
      payload.roadCondition || 'Mendaki + Berbatuan + Longsor',
      payload.weather || 'Cerah',
      payload.finishRank || 'JUARA 1 (#1/6)',
      Number(payload.raceTimeSeconds || 60).toFixed(2),
      Number(payload.distanceMeters || 0),
      Number(payload.driftScore || 0)
    ];

    sheet.appendRow(rowData);

    return {
      status: 'success',
      savedRow: rowData,
      leaderboard: getLeaderboard(10).data
    };
  } catch (err) {
    return {
      status: 'error',
      message: err.toString()
    };
  }
}

/**
 * Mengambil data Urutan Finish / Leaderboard terbaru dari Google Sheets.
 */
function getLeaderboard(limit) {
  try {
    const maxRows = limit || 10;
    const ss = getOrCreateSpreadsheet_();
    const sheet = ss.getSheetByName(DB_SHEETS.LEADERBOARD);
    if (!sheet || sheet.getLastRow() <= 1) {
      return { status: 'success', data: [] };
    }

    const lastRow = sheet.getLastRow();
    const numRows = Math.min(maxRows, lastRow - 1);
    const startRow = Math.max(2, lastRow - numRows + 1);
    const values = sheet.getRange(startRow, 1, numRows, 12).getValues();

    const records = values.reverse().map(function(r) {
      return {
        timestamp: String(r[0]),
        driverName: String(r[1]),
        vehicleCategory: String(r[2]),
        vehicleName: String(r[3]),
        paintColor: String(r[4]),
        trackLocation: String(r[5]),
        roadCondition: String(r[6]),
        weather: String(r[7]),
        finishRank: String(r[8]),
        raceTimeSeconds: Number(r[9]),
        distanceMeters: Number(r[10]),
        driftScore: Number(r[11])
      };
    });

    return {
      status: 'success',
      data: records
    };
  } catch (err) {
    return {
      status: 'error',
      message: err.toString(),
      data: []
    };
  }
}

/**
 * Helper internal: Mengambil Spreadsheet aktif atau membuat Spreadsheet baru jika standalone script.
 */
function getOrCreateSpreadsheet_() {
  let ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) {
    const props = PropertiesService.getScriptProperties();
    const savedId = props.getProperty('RACING_DB_SPREADSHEET_ID');
    if (savedId) {
      try {
        ss = SpreadsheetApp.openById(savedId);
      } catch (e) {
        ss = null;
      }
    }
    if (!ss) {
      ss = SpreadsheetApp.create('DB_REALISTIC_RACING_SIMULATOR_GORONTALO');
      props.setProperty('RACING_DB_SPREADSHEET_ID', ss.getId());
    }
  }
  return ss;
}
