# Petunjuk Singkat 3 Langkah — REALISTIC RACING SIMULATOR (GORONTALO 3D)

## Langkah 1: Inisialisasi Database & Proyek Google Apps Script
1. Buka **Google Sheets** baru di browser Anda (`https://sheets.new`) dan beri nama **`DB_REALISTIC_RACING_SIMULATOR_GORONTALO`**.
2. Klik menu **Extensions (Ekstensi) > Apps Script** pada bagian atas Google Sheets.
3. Pada file **`Code.gs`** di editor Apps Script, hapus kode bawaan lalu tempelkan seluruh isi kode dari **Bagian 1 (`Code.gs`)**.
4. Klik tombol **➕ (Tambahkan File) > HTML**, beri nama persis **`Index`** (tanpa menulis `.html`, sehingga menjadi `Index.html`), lalu tempelkan seluruh kode dari **Bagian 2 (`Index.html`)** dan tekan **Ctrl+S (Simpan)**.
5. Pada dropdown fungsi di toolbar atas editor Apps Script, pilih fungsi **`initDatabase`** lalu klik tombol **Run (Jalankan)**. Berikan izin akses (*Review Permissions > Allow*) agar sheet **`Leaderboard`** dan **`GarageLogs`** otomatis dibuat di Google Sheets Anda.

## Langkah 2: Deploy Web App
1. Klik tombol biru **Deploy > New deployment (Deployment baru)** di pojok kanan atas editor Google Apps Script.
2. Klik ikon roda gigi (⚙️) di samping *Select type*, lalu pilih **Web app**.
3. Isi konfigurasi berikut:
   - **Description**: `Realistic Racing Simulator Gorontalo 3D`
   - **Execute as (Jalankan sebagai)**: **Me** (Email Anda)
   - **Who has access (Siapa yang memiliki akses)**: **Anyone** (Siapa saja)
4. Klik **Deploy**, lalu salin tautan **Web app URL** (`https://script.google.com/macros/s/.../exec`) yang muncul.

## Langkah 3: Cara Pakai & Bermain
1. Buka **Web app URL** di browser komputer atau ponsel Anda (atau mainkan langsung di layar Canvas).
2. Di **Menu Utama / CUSTOM-PILIH MOBIL-MOTOR DAN WARNA**:
   - Ketik **Nama Pengemudi** dan pilih **Karakter Pembalap 3D ("Orangnya")**.
   - Pilih kategori kendaraan: **Mobil Sport** (*Ferrari SF90*, *Lamborghini Revuelto*, *Mercedes-AMG GT*, dll.) atau **Motor Balap 3D** (*Honda RC213V*, *Suzuki GSX-RR*, *KTM RC16*, *Aprilia RS-GP*, *Ducati Panigale V4R*, *Yamaha YZF-R1M*, *Kawasaki Ninja H2R*) beserta **Warna Cat**.
   - Pilih **Lokasi Sirkuit Gorontalo** (*Pegunungan Tilongkabila*, *Pesisir Olele*, *Puncak Dulamayo*, atau *Benteng Otanaha*), **Kondisi Medan Jalan** (*Mendaki*, *Berbatuan*, *Rawan Longsor*, atau *Kombinasi*), serta **Cuaca Dinamis** (*Cerah*, *Hujan Deras*, *Berawan*, *Kabut Tebal*, atau *Sore Senja*).
3. Klik **PLAY — MULAI BALAPAN** untuk berpacu selama **1 Menit (60 Detik)**. Saat waktu habis atau putaran selesai, **Urutan Finish (#1 s/d #6)** akan tampil di layar dan otomatis tersimpan ke database Google Sheets Anda!
